<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-primary text-capitalize fw-semibold px-4 py-2'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH D:\laragon\www\last_trah\resources\views/components/primary-button.blade.php ENDPATH**/ ?>
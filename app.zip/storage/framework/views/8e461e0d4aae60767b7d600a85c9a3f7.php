<?php
    $isMenu = false;
    $navbarHideToggle = false;
?>




<?php $__env->startSection('title', 'Data Keluarga'); ?>

<?php $__env->startSection('page-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="card p-5 text-lg font-medium text-black">
            <?php echo e(__('Profile')); ?>

    </h2>
    <div class="mt-2">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg mb-3">
                <div class="max-w-xl">
                    <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg mb-3">
                <div class="max-w-xl">
                    <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\last_trah\resources\views/profile/edit.blade.php ENDPATH**/ ?>
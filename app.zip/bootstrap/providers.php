<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\MenuServiceProvider::class,
    App\Providers\VoltServiceProvider::class,
    Spatie\Permission\PermissionServiceProvider::class
];
